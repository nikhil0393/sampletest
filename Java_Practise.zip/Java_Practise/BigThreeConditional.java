import java.util.Scanner;
class BigThreeConditional
{
   public static void main(String[] args)
   {
	Scanner s = new Scanner(System.in);
	System.out.println("Enter 3 numbers");
	int n1 = s.nextInt();
	int n2 = s.nextInt();
	int n3 = s.nextInt();
	int big = (n1>n2 && n1>n3) ? n1 : (n2>n3) ? n2 : n3;
	System.out.println("Bigg no is: "+big);
   }
}