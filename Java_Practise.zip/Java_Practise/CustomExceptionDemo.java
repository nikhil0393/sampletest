class AgeException extends Exception
{
   AgeException(String s)
   {
	super(s);
   }
   AgeException(){}
}
class Employee 
{
   void setAge(int age) throws AgeException
   {
	if(age<28 || age>60)
	   throw new AgeException("Age should be between 18 and 60");
	else
	   System.out.println("Your age is: "+age);
   }
}
class CustomExceptionDemo
{
   public static void main(String[] args)
   {
	Employee e = new Employee();
	try
	{
	   e.setAge(12);
	}
	catch(AgeException ae)
	{
	   System.out.println(ae);//invokes toString()
	   System.out.println(ae.getMessage());//returns message of exception
	   ae.printStackTrace();//displays the root cause of exception
	}
   }
}