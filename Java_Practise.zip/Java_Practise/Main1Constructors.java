class Account
{
   int accountNo;
   String accountType;
   int accountBalance;
   Account(int accountNo,String accountType,int accountBalance)
   {
	this.accountNo = accountNo;
	this.accountType = accountType;
	this.accountBalance = accountBalance;
   }
   Account(){}
   void withdraw()
   {
	accountBalance = accountBalance-1000;
   }
   void deposit()
   {
	accountBalance = accountBalance+1000;
   }
   void displayAccountDetails()
   {
	System.out.println("Account Number = "+accountNo);
	System.out.println("Account Type = "+accountType);
	System.out.println("Account Balance = "+accountBalance);
   }
}
class Main1Constructors
{
    public static void main(String[] args)
    {
	Account a = new Account(1001153150,"Current Account",50000);
	a.displayAccountDetails();
	a.withdraw();
	a.displayAccountDetails();
	a.deposit();
	a.displayAccountDetails();
    }
}