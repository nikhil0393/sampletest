import java.util.Scanner;
class DoWhileDemo
{
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		int bal,ch,amnt;
		System.out.println("Enter current balance");
		bal = s.nextInt();
		do
		{
			System.out.println("1.Deposit");
			System.out.println("2.Withdrawl");
			System.out.println("3.Display Balance");
			System.out.println("4.Exit");
			System.out.println("Enter a choice");
			ch=s.nextInt();
			switch(ch)
			{
				case 1: System.out.println("Enter amount to deposit");
					    amnt = s.nextInt();
					    bal = bal+amnt;
					    break;
				case 2: System.out.println("Enter amount to withdrawl");
						amnt = s.nextInt();
						if(amnt > bal)
							System.out.println("Insufficient Balance");
						else
							bal = bal-amnt;
						break;
				case 3: System.out.println("Current Balance= "+bal);break;
				case 4: System.exit(1);
				default: System.out.println("Invalid Choice");
			}
		}while(ch != 4);
	}
}