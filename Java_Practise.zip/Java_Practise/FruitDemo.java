abstract class Fruit
{
	abstract void cost();
}
class Apple extends Fruit
{
	int price;
	void expense(int price)
	{
		this.price = price;
	}
	void cost()
	{
		System.out.println("Cost of Apple per kg: "+price);
	}
}
class Mango extends Fruit
{
	int price;
	void expense(int price)
	{
		this.price = price;
	}
	void cost()
	{
		System.out.println("Cost of Mangos per kg: "+price);
	}
}
class FruitDemo
{
	public static void main(String[] args)
	{
		Apple a = new Apple();
		a.expense(20);
		a.cost();
		Mango m = new Mango();
		m.expense(40);
		m.cost();
	}
}