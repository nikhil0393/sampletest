class Rectangle
{
	int length;
	int breadth;
	double area;
	Rectangle(int length,int breadth)
	{
		this.length = length;
		this.breadth = breadth;
	}
	Rectangle(){}
	void area()
	{
		area = length*breadth;
	}
	void displayDetails()
	{
		System.out.println("Area of rectangle= "+area);
	}
}
class RectangleAreaConstructors
{
	public static void main(String[] args)
	{
		Rectangle r = new Rectangle(20,30);
		r.area();
		r.displayDetails();
	}
}