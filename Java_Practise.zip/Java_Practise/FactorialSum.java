class FactorialSum
{
	public static void main(String[] args)
	{
		System.out.println("-------------------------------------");
		System.out.println(" Number                    Factorial ");
		System.out.println("-------------------------------------");
		int sum=0;
		for(int i=1;i<=5;i++)
		{
			int f=1;
			for(int j=i;j>=1;j--)
			{
				f = f * j;
			}
			System.out.println("    "+i+"                       "+f);
			sum = sum + f;
		}
		System.out.println("-------------------------------------");
		System.out.println("          sum   =   "+sum);
		System.out.println("-------------------------------------");
	}
}