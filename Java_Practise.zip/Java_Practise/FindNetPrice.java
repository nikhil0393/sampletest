import java.util.Scanner;
class FindNetPrice
{
   public static void main(String[] args)
   {
	Scanner s = new Scanner(System.in);
	double price = 0;
	double discount = 0;
	double netPrice = 0;
	System.out.println("Enter item no");	
	int itemNum = s.nextInt();
	System.out.println("Enter item name");
	String itemName = s.next();
	System.out.println("Enter item rate");
	double itemRate = s.nextDouble();
	System.out.println("Enter item quantity");
	int itemQuantity = s.nextInt();
	price = itemRate*itemQuantity;
	if(price >= 1000 && price < 2000)
	   discount = 0.01*price;
	else if(price >= 2000 && price < 3000)
	   discount = 0.15*price;
	else if(price >= 3000 && price < 5000)
	   discount = 0.2*price;
	else if(price >= 5000)
	   discount = 0.25*price;
	netPrice = price-discount;
	System.out.println("Item no= "+itemNum);
	System.out.println("Item name= "+itemName);
	System.out.println("Item price= "+price);
	System.out.println("Item discount= "+discount);
	System.out.println("Item net price= "+netPrice);
   }
}