import java.util.Scanner;
class MajorMinor
{
    public static void main(String[] args)
    {
	Scanner s = new Scanner(System.in);
	System.out.println("Enter age");
	int age1 = s.nextInt();
	if(age1>=18)
	   System.out.println("Major");
	else
	    if(age1<18 && age1>0)
		System.out.println("Minor");
	    else
		System.out.println("Invalid number");
    }
}