import java.util.LinkedList;
import java.util.Scanner;
public class LinkedListOperations {

	public static void main(String[] args) {
		LinkedList ll = new LinkedList();
		ll.add(10);
		ll.add(20);
		ll.add("Sai");
		ll.add("Nikhil");
		System.out.println(ll);
		int ch;
		Scanner s = new Scanner(System.in);
		do
		{
			System.out.println("1.Add element at last:");
			System.out.println("2.Add element at first:");
			System.out.println("3.Add element at given position");
			System.out.println("4.Update element at given position");
			System.out.println("5.Delete element at first");
			System.out.println("6.Delete element at last");
			System.out.println("7.Delete element at given position");
			System.out.println("8.Delete the given element");
			System.out.println("9.Display elements");
			System.out.println("10.Exit");
			System.out.println("Choose an operation to perform");
			ch = s.nextInt();
			switch(ch)
			{
				case 1: System.out.println("Enter element to add at last");
						String emt1 = s.next();
						ll.addLast(emt1);
						System.out.println(ll);break;
				case 2: System.out.println("Enter element to add at first");
						String emt2 = s.next();
						ll.addLast(emt2);
						System.out.println(ll);break;
				case 3: System.out.println("Enter a position where element needs to be added");
						int p1 = s.nextInt();
						System.out.println("Enter element to add at given position");
						String emt3 = s.next();
						ll.add(p1, emt3);
						System.out.println(ll);break;
				case 4: System.out.println("Enter a position where element needs to be updated");
						int p2 = s.nextInt();
						System.out.println("Enter element to update at given position");
						String emt4 = s.next();
						ll.set(p2, emt4);
						System.out.println(ll);break;
				case 5: ll.removeFirst();
						System.out.println(ll);break;
				case 6: ll.removeLast();
						System.out.println(ll);break;
				case 7: System.out.println("Enter a position where element needs to be deleted");
						int p3 = s.nextInt();
						ll.remove(p3);break;
				case 8: System.out.println("Enter an element that needs to be deleted");
						String emt5 = s.next();
						ll.remove(emt5);
						System.out.println(ll);break;
				case 9: System.out.println(ll);break;
				case 10: System.exit(1);
				default: System.out.println("Invalid choice"); 
			}
		}while(ch != 10);
	}

}
