package mypack1;

public class MyClass {
	public static int m=10;
	public static int n=20;
	public static void xxx()
	{
		System.out.println("xxx");
	}

}
