import java.util.*;
public class StringTokenizerDemo {
	public static void main(String[] args) {
		String s = "Java is OO programming language";
		StringTokenizer st = new StringTokenizer(s," ");
		int count=0;
		while(st.hasMoreTokens())
		{
			System.out.println(st.nextToken());
			count++;
		}
		System.out.println("No of words= "+count);
		System.out.println();
		StringTokenizer ts = new StringTokenizer(s,"a");
		while(ts.hasMoreTokens())
		{
			System.out.println(ts.nextToken());
		}
	}

}
