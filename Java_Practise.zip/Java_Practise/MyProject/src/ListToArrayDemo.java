import java.util.*;
public class ListToArrayDemo {
	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		list.add("xxx");
		list.add("yyy");
		list.add("zzz");
		String[] s = list.toArray(new String[0]);
		for(String s1 : s)
			System.out.println(s1);
	}

}
