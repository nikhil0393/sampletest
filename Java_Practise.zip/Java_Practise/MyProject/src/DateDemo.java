import java.util.*;
public class DateDemo {
	public static void main(String[] args) {
		Date d = new Date();
		System.out.println("Current Date & Time : "+d);
	}

}
