package mypack2;
import mypack1.MyClass;
import static mypack1.MyClass.*;
public class StaticImportDemo {

	public static void main(String[] args) {
		System.out.println(m);
		System.out.println(n);
		xxx();
	}

}
