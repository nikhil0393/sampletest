import java.util.*;
public class UsingGenericsDemo {
	public static void main(String[] args) {
		LinkedList<String> ll = new LinkedList<String>();
		ll.add("xxx");
		ll.add("yyy");
		ll.add("zzz");
		System.out.println(ll);
		//Enhanced for loop instead of Iterator as generics is used
		for(String x : ll)
			System.out.println(x);
		//forEach() added in Java 8 can also be used
		ll.forEach(n -> System.out.println(n));
	}

}
