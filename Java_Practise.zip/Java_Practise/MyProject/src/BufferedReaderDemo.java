import java.io.*;
public class BufferedReaderDemo {
	public static void main(String[] args) throws Exception {
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in)))
		{
			System.out.println("Enter Number 1");
			int n1 = Integer.parseInt(br.readLine());
			System.out.println("Enter Number 2");
			int n2 = Integer.parseInt(br.readLine());
			int sum = n1+n2;
			System.out.println("Sum= "+sum);
		}
	}

}
