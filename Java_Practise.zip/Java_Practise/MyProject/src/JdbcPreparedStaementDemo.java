import java.sql.*;
import java.util.Scanner;
public class JdbcPreparedStaementDemo {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter Book No");
		int bno = in.nextInt();
		System.out.println("Enter Book Name");
		String bname = in.next();
		System.out.println("Enter Book Price");
		float price = in.nextFloat();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java14","root","root");
			/*PreparedStatement st = con.prepareStatement("insert into books values (?,?,?)");
			st.setInt(1, bno);
			st.setString(2, bname);
			st.setFloat(3, price);
			st.executeUpdate();*/
			//Alternate syntax to prepareStatement
			PreparedStatement st = con.prepareStatement("insert into books values ("+bno+",'"+bname+"',"+price+")");
			st.executeUpdate();
			System.out.println("Inserted");
			st.close();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
