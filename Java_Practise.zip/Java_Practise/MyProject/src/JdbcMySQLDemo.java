/*This program will give exception bcz jar file which contains Driver class 
is not loaded and database is also not created*/
import java.sql.*;
public class JdbcMySQLDemo {
	public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java14","root","root");
			System.out.println("Connected");
			con.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
