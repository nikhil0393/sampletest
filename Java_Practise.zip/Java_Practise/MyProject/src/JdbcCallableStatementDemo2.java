//to call procedures
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Types;
public class JdbcCallableStatementDemo2 {
	public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java14","root","root");
			CallableStatement st = con.prepareCall("{call getPrice(?,?)}");
			st.setInt(1, 111);
			st.registerOutParameter(2, Types.FLOAT);
			st.execute();
			float price = st.getFloat(2);
			System.out.println("Price = "+price);
			st.close();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
