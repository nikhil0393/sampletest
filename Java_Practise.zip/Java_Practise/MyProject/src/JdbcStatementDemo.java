import java.sql.*;
public class JdbcStatementDemo {
	public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java14","root","root");
			Statement st = con.createStatement();
			/*st.execute("create table books(bno int(3),bname varchar(10),price float(4))");
			System.out.println("Table created");*/
			/*st.executeUpdate("insert into books values (111,'java',600)");
			st.executeUpdate("insert into books values (222,'xml',800)");
			st.executeUpdate("insert into books values (333,'html',400)");
			System.out.println("Inserted");*/
			/*int n = st.executeUpdate("update books set price=700");
			System.out.println(n+" records updated");*/
			/*int m = st.executeUpdate("delete from books");//deletes all records
			System.out.println(n+" Records deleted");*/
			ResultSet rs = st.executeQuery("select * from books");
			while(rs.next())
			{
				System.out.println(rs.getInt("bno")+" ");
				System.out.println(rs.getString("bname")+" ");
				System.out.println(rs.getFloat(3));//3 is column no i.e price
			}
			st.close();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
