import java.util.*;
public class MapDemo {
	public static void main(String[] args) {
		//HashMap - unordered and no duplicates
		HashMap hm = new HashMap();
		hm.put("monitor", 1000);
		hm.put("keyboard", 5000);
		hm.put("mouse", 3000);
		hm.put("ups", 2000);
		hm.put("speakers", 1000);
		System.out.println(hm);
		//LinkedHashMap - ordered and no duplicates
		LinkedHashMap lhm = new LinkedHashMap();
		lhm.put("monitor", 1000);
		lhm.put("keyboard", 5000);
		lhm.put("mouse", 3000);
		lhm.put("ups", 2000);
		lhm.put("speakers", 1000);
		System.out.println(lhm);
		//TreeMap - sorted and no duplicates
		TreeMap tm = new TreeMap();
		tm.put("monitor", 1000);
		tm.put("keyboard", 5000);
		tm.put("mouse", 3000);
		tm.put("ups", 2000);
		tm.put("speakers", 1000);
		System.out.println(tm);
	}

}
