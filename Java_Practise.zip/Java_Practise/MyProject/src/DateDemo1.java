import java.text.SimpleDateFormat;
import java.util.*;
public class DateDemo1 {
	public static void main(String[] args) throws Exception{
		Scanner in = new Scanner(System.in);
		System.out.println("Enter date");
		String myDate = in.next();
		Date dt = new SimpleDateFormat("dd/MM/yy").parse(myDate);
		SimpleDateFormat sdf = new SimpleDateFormat("MMMM/dd/yyyy");
		System.out.println(sdf.format(dt));
	}

}
