class GenClass <T>
{
	T i;
	GenClass(T i)
	{
		this.i = i;
	}
	T getValue()
	{
		return i;
	}
}
/*class StringClass
{
	String s;
	StringClass(String s)
	{
		this.s = s;
	}
	String getStringValue()
	{
		return s;
	}
}*/
public class GenericsDemo {

	public static void main(String[] args) {
		/*StringClass sc = new StringClass("Hello");
		System.out.println(sc.getStringValue());*///Hello
		GenClass<Integer> gc = new GenClass<Integer>(10);
		System.out.println(gc.getValue());//10
		GenClass<String> gc1 = new GenClass<String>("Hello");
		System.out.println(gc1.getValue());//Hello
		
	}

}
