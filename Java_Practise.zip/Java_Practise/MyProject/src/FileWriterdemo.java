import java.io.*;
public class FileWriterdemo {
	public static void main(String[] args) throws IOException{
		FileWriter fw = new FileWriter("file3.txt");
		BufferedWriter bw = new BufferedWriter(fw);
		String s = "Java is a automatic garbage collector";
		//fw.write(s);
		bw.write(s);
		System.out.println("File Created");
		bw.close();
		fw.close();
	}

}
