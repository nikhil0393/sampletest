import java.io.*;
public class FileReaderPractise {
	public static void main(String[] args) throws IOException{
		FileReader fr = new FileReader("//capgroup.com/MyDocs/inysiam/My Documents/LONGTAIL/WT-Templates-Pages.xlsx");
		int n;
		while()
	}

}
