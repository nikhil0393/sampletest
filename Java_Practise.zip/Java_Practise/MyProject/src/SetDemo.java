import java.util.*;
public class SetDemo {
	public static void main(String[] args) {
		//HashSet - unordered & no duplicates
		HashSet hs = new HashSet();
		hs.add("monitor");
		hs.add("keyboard");
		hs.add("mouse");
		hs.add("ups");
		hs.add("speakers");
		hs.add("monitor");
		System.out.println(hs.add("monitor"));//false-return type of add(); as set cannot contain duplicates
		System.out.println(hs);
		//LinkedHashSet - ordered & no duplicates
		LinkedHashSet lhs = new LinkedHashSet();
		lhs.add("monitor");
		lhs.add("keyboard");
		lhs.add("mouse");
		lhs.add("ups");
		lhs.add("speakers");
		lhs.add("monitor");
		System.out.println(lhs.add("monitor"));//false-return type of add() as set cannot contain duplicates
		System.out.println(lhs);
		//TreeSet - sorted & no duplicates
		TreeSet ts = new TreeSet();
		ts.add("monitor");
		ts.add("keyboard");
		ts.add("mouse");
		ts.add("ups");
		ts.add("speakers");
		ts.add("monitor");
		//ts.add(10); //ClassCast Exception
		System.out.println(ts.add("monitor"));//false-return type of add() as set cannot contain duplicates
		System.out.println(ts);
		System.out.println(ts.descendingSet());//descending order
		List<Integer> phoneNos = new ArrayList<Integer>();
		phoneNos.add(1111);
		phoneNos.add(2222);
		phoneNos.add(3333);
		phoneNos.add(1111);
		phoneNos.add(4444);
		phoneNos.add(5555);
		phoneNos.add(6666);
		phoneNos.add(4444);
		phoneNos.add(3333);
		phoneNos.add(7777);
		System.out.println(phoneNos);
		Set<Integer> uniquePhoneNos = new LinkedHashSet<Integer>();
		uniquePhoneNos.addAll(phoneNos);
		System.out.println(uniquePhoneNos);
	}

}
