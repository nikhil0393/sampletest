interface MyInterface
{
	
}
public class PrivateInterfaceDemo {

	public static void main(String[] args) {

	}

}
