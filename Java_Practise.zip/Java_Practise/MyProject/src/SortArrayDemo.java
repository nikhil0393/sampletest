import java.util.*;
public class SortArrayDemo {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n[] = new int[5];
		System.out.println("Enter 5 elements");
		for(int i=0;i<n.length;i++)
			n[i] = in.nextInt();
		System.out.println("Given Array Elements");
		for(int x : n)
			System.out.print(x+" ");
		Arrays.sort(n);
		System.out.println();
		System.out.println("Sorted Array Elements");
		for(int z : n)
			System.out.print(z+" ");
	}

}
