//to call functions
import java.sql.*;
public class JdbcCallableStatementDemo1 {
	public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java14","root","root");
			CallableStatement st = con.prepareCall("{? = call f_get_price(?)}");
			st.setInt(2, 111);
			st.registerOutParameter(1, Types.FLOAT);
			st.execute();
			float price = st.getFloat(1);
			System.out.println("Price = "+price);
			st.close();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
