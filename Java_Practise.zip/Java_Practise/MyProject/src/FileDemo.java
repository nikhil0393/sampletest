import java.io.*;
public class FileDemo {
	public static void main(String[] args) throws IOException {
		/*File mydir = new File("MyDir");
		mydir.mkdir();
		System.out.println("Folder Created");
		File f1 = new File(mydir,"emp.txt");
		f1.createNewFile();
		System.out.println("File Created");*/
		File f = new File("item.txt");
		if (f.exists())
		{
			System.out.println("File already exists");
			FileInputStream fis = new FileInputStream(f);
			int size = fis.available();
			byte[] buffer = new byte[size];
			fis.read(buffer);
			String s = new String(buffer);
			System.out.println(s);
			fis.close();
		}
		else
		{
			FileOutputStream fos = new FileOutputStream(f);
			fos.write("Item Details".getBytes());
			System.out.println("File Created");
			fos.close();
		}
	}

}
