import java.util.*;
public class ArrayToListDemo {
	public static void main(String[] args) {
		String[] s = {"xxx","yyy","zzz"};
		List<String> list = new ArrayList<String>();
		list = Arrays.asList(s);
		System.out.println(list);
		for(String s1 : list)
			System.out.println(s1);
	}

}
