import java .util.*;
public class TraverseDemo {
	public static void main(String[] args) {
		LinkedList ll = new LinkedList();
		ll.add(10);
		ll.add(20);
		ll.add("xxx");
		ll.add("yyy");
		System.out.println(ll);
		//Iterator interface
		Iterator iter = ll.iterator();
		while(iter.hasNext())
		{
			System.out.println(iter.next());
		}
		//ListIterator interface
		ListIterator listIter = ll.listIterator();
		while(listIter.hasNext())
		{
			System.out.println(listIter.next());
		}
		while(listIter.hasPrevious())
		{
			System.out.println(listIter.previous());
		}
		//Enumeration interface
		Vector v = new Vector();//smilar to ArrayList but methods are synchronized
		v.add("xxx");
		v.add(10);
		v.add("yyy");
		System.out.println(v);
		Enumeration e = v.elements();
		while(e.hasMoreElements())
		{
			System.out.println(e.nextElement());
		}
	}

}
