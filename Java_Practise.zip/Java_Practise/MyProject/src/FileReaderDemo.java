import java.io.*;
public class FileReaderDemo {
	public static void main(String[] args) throws IOException {
		FileReader fr = new FileReader("C:/Users/inysiam/Downloads/NewFolder/MyProject/src/FileReaderDemo.java");
		int n;
		while((n = fr.read()) != -1)//-1 indicates EOF
		{
			System.out.print((char)n);
		}
		fr.close();
		/*System.out.println();
		char x = 'i';
		System.out.println((int)x);*///unicode for char i
	}

}
