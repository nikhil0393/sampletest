class CheckedExceptiondemo
{
   public static void main(String[] args) throws Exception
   {
	/*try
	{
	   int n = System.in.read();
	}catch(Exception e){}*/
	int n = System.in.read();
   }
}