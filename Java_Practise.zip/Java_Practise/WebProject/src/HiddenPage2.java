import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class HiddenPage2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String username = request.getParameter("username");//reading hidden field from HiddenPage1
		if (username != null)
		{
			out.println("Welcome "+username);
		}
		else
			//out.println("Invalid session");
			response.sendRedirect("/WebProject/hidden.html");
	}
}
