import java.io.*;
import java.net.InetAddress;

import javax.servlet.*;
public class LogFilter implements Filter {
	public void destroy() 
	{
		
	}
	public void doFilter(ServletRequest request, ServletResponse response, 
			FilterChain chain) throws IOException, ServletException {
		//preprocessing logic
		String ipAddr = request.getRemoteAddr();
		if(ipAddr.equals("0:0:0:0:0:0:0:1"))
		{
			InetAddress inetAddress = InetAddress.getLocalHost();
			String ipAddress = inetAddress.getHostAddress();
			ipAddr = ipAddress;
		}
		System.out.println("IP Address : "+ipAddr);
		System.out.println("Time Connected : "+new java.util.Date());
		chain.doFilter(request, response);
		//postprocessing logic
		System.out.println("Request is processed");
	}
	public void init(FilterConfig fConfig) throws ServletException {
	}

}
