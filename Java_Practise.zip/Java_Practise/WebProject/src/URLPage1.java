import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class URLPage1 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	PrintWriter out = response.getWriter();
	String username = request.getParameter("username");
	out.println("Welcome <a href=/WebProject/URLPage2?username="+username+">Next Page</a>");
	}
}
