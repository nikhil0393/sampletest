import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class HelloServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html"); //optional bcoz by default content type is HTML
		out.println("<html>");
		out.println("<body>");
		out.println("<font face=\"arial\" size=\"5\" color=\"blue\">Hello to all</font>");
		out.println("</body>");
		out.println("</html>");
	}
}
