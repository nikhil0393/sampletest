import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class HiddenPage1 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String username = request.getParameter("username");
		out.println("Welcome Click to proceed...<br>");
		out.println("<form action=\"/WebProject/HiddenPage2\">");
		out.println("<input type=\"hidden\" name=\"username\" value="+username+">");
		out.println("<input type=\"submit\" value=\"submit\"");
		out.println("</form>");
	}
}
