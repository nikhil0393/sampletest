import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.mysql.jdbc.Connection;
public class ServletConfigDemo extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		ServletConfig config = getServletConfig();//getServletConfig is method of genericServlet class so object is not used
		String driver = config.getInitParameter("driver");
		String url = config.getInitParameter("url");
		String username = config.getInitParameter("username");
		String password = config.getInitParameter("password");
		try
		{
			Class.forName(driver);
			Connection con = (Connection) DriverManager.getConnection(url,username,password);
			out.println("Connected");
			con.close();
		}
		catch(Exception e)
		{}
	}
}
