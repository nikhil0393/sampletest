package mypack;

import java.sql.DriverManager;
import java.sql.*;
public class InsertCustomer {
	public static boolean saveCustomer(Customer cust)
	{
		int n=0;
		String username = cust.getUsername();
		String password = cust.getPassword();
		int age = cust.getAge();
		String email = cust.getEmail();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java14","root","root");
			PreparedStatement st = con.prepareStatement("insert into Customer values ('"+username+"','"+password+"',"+age+",'"+email+"')");
			n = st.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		if (n == 1)
			return true;
		else
			return false;
	}
}
