import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class CreateCookieServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		Cookie c1 = new Cookie("ItenNum",request.getParameter("ino"));
		Cookie c2 = new Cookie("ItemName",request.getParameter("iname"));
		response.addCookie(c1);
		response.addCookie(c2);
		out.println("Cookies Created");
	}
}
