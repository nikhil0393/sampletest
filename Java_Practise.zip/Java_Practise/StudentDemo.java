class Student
{
   int rollNum;
   String studName;
   int mark1;
   int mark2;
   int mark3;
   double totalMarks;
   void setStudDetails(int rollNum,String studName,int mark1,int mark2,int mark3)
   {
	this.rollNum = rollNum;
	this.studName = studName;
	this.mark1 = mark1;
	this.mark2 = mark2;
	this.mark3 = mark3;
   }
   void calculateTotal()
   {
  	totalMarks = mark1+mark2+mark3;
   }
   void displayStudDetails()
   {
	System.out.println("Student roll number is: "+rollNum);
	System.out.println("Student name is: "+studName);
	System.out.println("Total marks of student: "+totalMarks);
   }
}
class StudentDemo
{
    public static void main(String[] args)
    {
	Student s = new Student();
	s.setStudDetails(1001153150,"Nikhil",80,90,65);
	s.calculateTotal();
	s.displayStudDetails();
    }
}