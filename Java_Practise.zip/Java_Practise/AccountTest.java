class Customer
{
	int custId;
	String custName;
	String custAddress;
	Customer(int custId,String custName,String custAddress)
	{
		this.custId = custId;
		this.custName = custName;
		this.custAddress = custAddress;
	}
	void display()
	{
		System.out.println("Cutomer id: "+custId);
		System.out.println("Customer Name: "+custName);
		System.out.println("Customer Address: "+custAddress);
	}
}
class Account
{
	int acctId;
	String acctType;
	double acctBalance;
	Customer c1;
	Account(int acctId,String acctType,double acctBalance,Customer c1)
	{
		this.acctId = acctId;
		this.acctType = acctType;
		this.acctBalance = acctBalance;
		this.c1 = c1;
	}
	void display()
	{
		System.out.println("Account ID: "+acctId);
		System.out.println("Account Type: "+acctType);
		c1.display();
		System.out.println("Account Balance: "+acctBalance);
	}
}
class AccountTest
{
	public static void main(String[] args)
	{
		Customer c = new Customer(10011,"Nikhil","29 Bear Paw,Irvine,CA,92604");
		//c.display();
		Account a = new Account(53150,"Current Accnt",40000,c);
		a.display();
	}
}