class WithdrawException extends Exception
{
	WithdrawException(String s)
	{
		super(s);
	}
	WithdrawException(){}
}
class Account
{
	int balance = 50000;
	void withdraw(int amount) throws WithdrawException
	{
		if(amount > balance)
			throw new WithdrawException("Insufficient balance");
		else
			System.out.println("Withdrawal amount is: "+amount);
	}
}
class UserDefinedExceptionDemo
{
	public static void main(String[] args)
	{
		Account a = new Account();
		try
		{
			a.withdraw(60000);
		}catch(WithdrawException we)
		{
			System.out.println(we);
		}
	}
}