//Constructors in Polymorphism Assignment
class Book
{
	int bno;
	String bname;
	int price;
	Book(int bno,String bname,int price)
	{
		this.bno = bno;
		this.bname = bname;
		this.price = price;
	}
	Book(){}
	void display()
	{
		System.out.println("Book Number: "+bno);
		System.out.println("Book Name: "+bname);
		System.out.println("Book Price: "+price);
	}
}
class SpecialEditionBook extends Book
{
	double discount;
	SpecialEditionBook(int bno,String bname,int price,double discount)
	{
		super(bno,bname,price);
		this.discount = discount;
	}
	SpecialEditionBook(){}
	void display()
	{
		super.display();
		System.out.println("Discount value: "+discount);
	}
}
class BookTest
{
	public static void main(String[] args)
	{
		//Book b = new Book();
		SpecialEditionBook seb = new SpecialEditionBook(405,"HarryPotter",50,20);
		seb.display();
	}
}